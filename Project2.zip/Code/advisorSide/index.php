<?php
session_start();
$debug = false;
include('../CommonMethods.php');
echo("<title>Advisor Home</title>");

$COMMON = new Common($debug);
$_SESSION['confirmedPass'] = false;
$_SESSION['apptExists'] = false;
$name = $_SESSION['first'];

// Get meeting ID's for this advisor using their last name
$last = $_SESSION['last'];
$sql = "SELECT `index` FROM `meetings` WHERE `advisor_last_name`='$last'";
$rs = $COMMON->executeQuery($sql, $_SERVER["SCRIPT_NAME"]);

// Notification string
$notification = "";

// Loop through the meeting ID's for the advisor
while ($meetingID = mysql_fetch_assoc($rs)) {
	$ID = $meetingID['index'];

	// Check if any of the advisor's meeting IDs are in the 'notifications' table and if they are, create the notification
	$sql = "SELECT * FROM `notifications` WHERE `meetingID`='$ID'";
	$rs = $COMMON->executeQuery($sql, $_SERVER["SCRIPT_NAME"]);
	
	// Loop through the records in the 'notifications' table with the advisor's meeting IDs
	while ($row = mysql_fetch_assoc($rs)) {
		// Get the student's info
		$studentID = $row['studentID'];
		$sql = "SELECT * FROM `students_basic_info` WHERE `id`='$studentID'";
		$rs2 = $COMMON->executeQuery($sql, $_SERVER["SCRIPT_NAME"]);
		$studentInfo = mysql_fetch_row($rs2);

		$studentLast = $studentInfo[1];
		$studentFirst = $studentInfo[2];
		$studentUMBCID = $studentInfo[4];

		// Find time and date of cancelled meeting
		$sql = "SELECT * FROM `meetings` WHERE `index`='$ID'";
		$rs3 = $COMMON->executeQuery($sql, $_SERVER["SCRIPT_NAME"]);
		$meetingInfo = mysql_fetch_row($rs3);

		$time = $meetingInfo[1];
		$date = $meetingInfo[2];

		// Add to notification string
		$cancelInfo = $studentFirst . " " . $studentLast . " cancelled their appointment with you on " . $date . " at " . $time . "<br/>";
		$notification .= $cancelInfo;

	}
}

if ($notification != "") {
	$_SESSION['finalNotif'] = $notification;
} else {
	$_SESSION['finalNotif'] = "You have no new notifications.";
}


//END TEST

// Confirm that the user is an advisor
if ($_SESSION['type'] != 'advisor') {
  header('Location: ../index.php');
}

include('../assets/header.html');
?>

<div style='text-align: center;'>
	<button style='background-color: red; border: none; font-size: 13px; font-family: Georgia, serif;' onclick='displayNotif()'>Notifications</button>
</div>

<h1>Welcome, <?php echo "$name";?></h1>
<form action='processAdvisorHome.php' method='post' name='advisorHome'>
  <input type='submit' name='next' value='Create Appointments'><br/>
  <input type='submit' name='next' value='View Appointments'><br/>
  <input type='submit' name='next' value='Edit Your Account Info'><br/>
  <input type='submit' name='next' value='Create New Advisor'><br/>
  <input type='submit' name='next' value='Reset Site'><br/>
  <input type='submit' name='next' value='Logout'><br/>
</form>

<script>
	function displayNotif() {
		window.location.href='notifications.php';
	}
</script>

</body>
</html>


