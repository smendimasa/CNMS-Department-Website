<?php
session_start();

include('../assets/header.html');
?>

<!-- Display text that confirms that the advisor's information has been updated -->
<form>
<h3>Info updated!</h3>
</form>

</body>
</html>


