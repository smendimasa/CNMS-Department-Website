<?php
session_start();

include('../assets/header.html');
?>

<!-- Display text that confirms that an advisor was created -->
<title>Advisor Created!</title>
<form>
<h3>Advisor Created!</h3>
</form>

</body>
</html>


