<?php
session_start();

include("../assets/header.html")
?>

<!-- Display text that confirms that a meeting was created -->
<form>
<center><h3>Meeting Created!</h3></center>
</form>
</body>
</html>